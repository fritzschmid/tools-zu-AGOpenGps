/*
Hydraulikwaage eingang A1 wird 16 x gelesen
und am Display 2 x je Sec angezeigt
Display ist ein 4*20 zeichen AlphaNumerischen LCD Display 
am Displayport sind Fritztasten mit Zurueck + - Eingabe

Aktuelles Gewicht wird GROSS angezeigt
die Waage wird im Menue eingestellt
mit Druck von leergewicht auf 0kg
mit RefenrenzDruck für Last mit entsprechenden Referenzgewicht
mit TARA fuer spaeteren nullwert

Zusätzlich: bei wiegen mit Tara ohne die Waage in den Einstellungen zu verändern

Tara => Eingabe -> Eingabe -> Eingabe

*/
// include the library code:
#include <LiquidCrystal.h>//LCD Display max 20*4
#include <EEPROM.h> //eeprom Funktionen
#include "Adafruit_ADS1015.h"
Adafruit_ADS1115 ads;     // Instanz von ADS1115

  #define ADC_Mode 1           //0 = No ADS installed - Sensor Signal auf Arduino A0
                               //1 = ADS1115 Single Mode - Sensor Signal to A0
                               //2 = ADS1115 Differential Mode - Sensor GND to A1, Signal to A0


//Steuerungsbits fuer LCD-Module 4 BitModus mit FS-Tastatur
//Tastatur FS: 255 für nix gedrueckt 254 fuer gedrueckt aber vorbei
// 10=Zurueck
// 11=Ab oder weniger
// 12=Auf oder mehr
// 13=Eingabe
// bei 11 & 12 bei längerer betaetigung 111 & 112 tastenwiederholung
const byte LcdRS=8;//Pin4 Taste Eingabe
const byte LcdRW=7;//Pin5 Taste Plus fuer alle Tasten
const byte LcdEN=6;//Pin6
const byte LcdD4=5;//Pin11
const byte LcdD5=4;//Pin12
const byte LcdD6=3;//Pin13 Taste Minus und gemeinsam mit Plus zurueck
const byte LcdD7=2;//Pin14 Taste Plus und gemeinsam mit Minus zurueck
//Pin1(-)Vss, Pin2(+)Vdd, Pin3Vo Kontrast, 
// Pin7=D0,Pin8=D1, Pin9=D2, Pin10=D3
// Pin15 Bel.LED+, Pin16 Bel.Led- 
// LCD20*4mit Rs=12, RW=11, En=10, D4=5, D5=4, D6=3, D7=2
//LiquidCrystal lcd(7,8,6,5,4,3,2);//RW nicht angeschlossen==Masse 13 Beleuchtung
//LiquidCrystal lcd(34,32,30,28,26,24,22);//RW nicht angeschlossen==Masse 13 Beleuchtung
LiquidCrystal lcd(LcdRS,LcdRW,LcdEN,LcdD4,LcdD5,LcdD6,LcdD7);//10==Beleuchtung
const byte Beleuchtung=12;// Beleuchtung Display auf masse=ON
//Menue und index
const int VERSION=101;
byte bereich;
byte index;
byte me;
//Allgemein
int wert;

const int VarAllgMax=5;
long VarAllg[VarAllgMax];
//Min-Max Tabellen  {Tarakg,refNULL,RefKG    ,kg
long WERTMINAllg[]={-999  ,1      ,1        ,1      ,0 };//SollTemp,Regelbereich,Ein,nullabgleich,verstärkung
long WERTMAXAllg[]={1999  ,20000  ,30000    ,2000   ,1000 };
long wertmax;
long wertmin;

const int gegaetMax=6;
int geraet;

bool hoch;
long WertF; //Floatwert für Anzeige;
//int WertI=0; //IntWert fuer Anzeige

byte TasteW;//Tastenwiederholung
byte TasteA;//AlterTastenwert
byte taste;//Tastencode
//byte Taste;
int menueexit;
unsigned long loopzeit=200; //SchleifenzeitVariable

byte bar1[8] = 
{
        B11100,
        B11110,
        B11110,
        B11110,
        B11110,
        B11110,
        B11110,
        B11100
};
byte bar2[8] =
{
        B00111,
        B01111,
        B01111,
        B01111,
        B01111,
        B01111,
        B01111,
        B00111
};
byte bar3[8] =
{
        B11111,
        B11111,
        B11111,
        B00000,
        B00000,
        B00000,
        B00000,
        B11111
};
byte bar4[8] =
{
        B11111,
        B11111,
        B00000,
        B00000,
        B00000,
        B11111,
        B11111,
        B11111
};
byte bar5[8] =
{
        B11111,
        B11111,
        B11111,
        B00000,
        B00000,
        B00000,
        B00000,
        B00000
};
byte bar6[8] =
{
        B00000,
        B00000,
        B00000,
        B00000,
        B00000,
        B11111,
        B11111,
        B11111
};
byte bar7[8] =
{
        B11111,
        B01111,
        B00000,
        B00000,
        B00000,
        B00000,
        B00000,
        B00000
};
byte bar8[8] =
{
        B00011,
        B00111,
        B01111,
        B11110,
        B00000,
        B00000,
        B00000,
        B00000
};
 //Variables  
long adWert;
long kg;
long NettoKG;
/* 
 *  
 int EEread = 0; // adressenpuffer 
#define EEP_Ident 0xEDED // als ID die im ersten speicherplatz gefunden werden muss
  struct Storage {//18Bytes lang
float TaraKG;
float NullWert;
float RefWert;
float RefKG;
int WertI;//reserviert
};  Storage Settings;
*/
// ohne Struktur... je 4 Bytes
//gespeichert in eeprom adress = (20*bereich)+(index*4);
int adress=0;
    //VarAllg[0] => Tara
    //VarAllg[1] => NULL Referenzwert
    //VarAllg[2] => Referenzwert mit gewicht
    //VarAllg[3] => Referenzgewicht
    

float TaraKG;
float NullWert;
float RefWert;
float RefKG;



void setup() {
  //set up communication
  Wire.begin();
  Serial.begin(38400);
    //50Khz I2C
  TWBR = 144;
delay (300);
  pinMode(13,OUTPUT);
  digitalWrite(13,LOW);
  //Variablen laden per Struktur
/*  EEPROM.get(0, EEread);               // read identifier
 if (EEread != (int)EEP_Ident){           // check on first start and write EEPROM
    EEPROM.put(0, EEP_Ident);
//    EEPROM.put(2, TaraKG);
//Default
    Settings.TaraKG=200;
    Settings.RefKG=1000;
    Settings.RefWert=30000;
    Settings.NullWert=10000;
    EEPROM.put(2, Settings);   
  }
 else 
  { 
    EEPROM.get(2, Settings);     // read the Settings
//    EEPROM.get(2, EEread);            // read Tara
//    if (EEread != TaraKG){
//      EEPROM.put(2, TaraKG);    // if changed , rewrite
//      Settings.TaraKG = (TaraKG);  //use new steering zero offset now
//      EEPROM.put(8, Settings);   
    }
    */
// ende variablen laden
  DisplayInitalisieren();
  
  GeraetLaden();
  VariablenLaden();
  loopzeit=millis();
  loop();
 }

void DisplayInitalisieren(){// erstes programm nach setup
   lcd.begin(4,20);// 4zeilen 20zeichen
   lcd.clear();
//  lcd.createChar(0,bar0);//geht ned
  lcd.createChar(1,bar1);
  lcd.createChar(2,bar2);
  lcd.createChar(3,bar3);
  lcd.createChar(4,bar4);
  lcd.createChar(5,bar5);
  lcd.createChar(6,bar6);
  lcd.createChar(7,bar7);
  lcd.createChar(8,bar8);
/////////end of bigfont stuff
   digitalWrite(Beleuchtung,LOW);
   delay(100);
   lcd.clear();
   // Print a message to the LCD.
   delay(100);
 // VariablenLaden();
 loopzeit=millis();
  return;
 } 

void loop() {//nächstes programm nach setup und init
  

  while(loopzeit > millis()){
  }//warte restzeit ab.....
    loopzeit=millis()+500;//lade neuen delaywert und arbeite das programm erstmal ab
  me++;
  if (me>3){
    me=0;
    digitalWrite(13,!digitalRead(13));//blinken
  }
    Tastatur();
  if(taste==13){
    HauptMenue();
    DisplayInitalisieren();
  }
  if(taste==110){
    VarAllg[0]=kg;
    WertSichern();
  }
  if(taste==12){
  }
  if(taste==11){
  }
  SensorMessen();// analogpin 0 für simulationsgeschwindigkeit 1 - 34 kmh
  Wert4_1Gross(0,0,NettoKG);
Serial.print(adWert);Serial.print("\t");Serial.println(NettoKG);
  
//    lcd.print(WertF);

}

void SensorMessen(){
if (analogRead(1)>250){hoch=true;}else{hoch=false;}
  float ergebnis=0;
  #if ADC_Mode==0    //Arduino A0
    //Analogpin 0 - 1023
    //zum testen wert von -1900 bis +9870
    int i=0;
    adWert=analogRead(0);// analogpin 
    while (i<9){
      i++;
      adWert+=analogRead(0);// analogpin 
    }
    adWert-=921;
  #endif
  #if ADC_Mode==1   //ADS1115 Single Mode
    //Connect Sensor Signal to A0
    adWert  = ads.readADC_SingleEnded(0);   delay(1);    
//    adWert += ads.readADC_SingleEnded(0);   delay(1);    
//    adWert += ads.readADC_SingleEnded(0);   delay(1);    
    adWert += ads.readADC_SingleEnded(0);
    adWert = adWert/2;    //divide by 2
  #endif 

  #if ADC_Mode==2    //ADS1115 Differential Mode
    //Connect Sensor Signal to A0 : Connect Sensor GND to A1
    adWert  = ads.readADC_Differential_0_1();   delay(1);    
//    adWert += ads.readADC_Differential_0_1();   delay(1);    
//    adWert += ads.readADC_Differential_0_1();   delay(1);    
    adWert += ads.readADC_Differential_0_1();
    adWert = adWert/2;    //divide by 2
  #endif 

    //VarAllg[0] => Tara
    //VarAllg[1] => NULL Referenzwert
    //VarAllg[2] => Referenzwert mit gewicht
    //VarAllg[3] => Referenzgewicht
    
    ergebnis=(double(adWert)-double(VarAllg[1]))/((double(VarAllg[2])-double(VarAllg[1]))/double(VarAllg[3]));
    
    //kg=(adWert-VarAllg[1])/(VarAllg[2]/VarAllg[3]);
    kg=ergebnis*100;
    
    NettoKG=kg-VarAllg[0];//abzug TARA
    if (hoch==true){
      NettoKG-=(VarAllg[4]*100);// hoch abziehen Freihub beendet
    }
      lcd.setCursor( 23,1);// Zeile, Position = 0 beginnend
      FormatL8d0(adWert);//formatiert rechtsbündig BYTEwert
      lcd.setCursor( 20,1);// Zeile, Position = 0 beginnend
      lcd.print("      ");
      lcd.setCursor( 21,1);// Zeile, Position = 0 beginnend
      lcd.print(geraet);
      if (hoch==true){lcd.print("h");}
      lcd.setCursor( 31,1);// Zeile, Position = 0 beginnend
      FormatL6d1(NettoKG);//formatiert rechtsbündig BYTEwert
 
}

//*********************************************************************************************************
byte Tastatur(){
//    delay(10);        // delay in between reads for stability
//LiquidCrystal lcd(7,8,6,5,4,3,2);//RW nicht angeschlossen==Masse 13 Beleuchtung
//LiquidCrystal lcd(34,32,30,28,26,24,22);//RW nicht angeschlossen==Masse 13 Beleuchtung
//LiquidCrystal lcd(LcdRS,LcdRW,LcdEN,LcdD4,LcdD5,LcdD6,LcdD7);//RW nicht angeschlossen==Masse 13 Beleuchtung
  taste=255;
  if (menueexit>0){menueexit--;}
 //   pinMode(OUTPUT,LcdEN);//TastaturEnable;EN
 //   digitalWrite(LcdEN,HIGH);// Ten=HIGH;
    pinMode(LcdRS,INPUT);//BEn=LOW;
    pinMode(OUTPUT,LcdRW);//TastaturEnable;RS
    digitalWrite(LcdRW,HIGH);// Ten=HIGH;
//    delay(1);
    pinMode(LcdD7,INPUT);//Bmi=LOW;
    pinMode(LcdD6,INPUT);//Bpl=LOW;
//    delay(1);
    if (digitalRead(LcdD6)==HIGH) {taste=11;}
    if (digitalRead(LcdD7)==HIGH) {taste=12;}  
    if (digitalRead(LcdRS)==HIGH) {taste=13;}  
    if ((digitalRead(LcdD7)==HIGH)&(digitalRead(LcdD6)==HIGH)) {taste=10;}  
    pinMode(LcdD7,OUTPUT);//Bmi=LOW;
    pinMode(LcdD6,OUTPUT);//Bpl=LOW;
    pinMode(LcdRS,OUTPUT);//BEn=LOW;
    digitalWrite(LcdRW,LOW);//Ten=LOW; 
 //   delay(1);        // delay in between reads for stability
  if(TasteW<255)   {TasteW++;        }//Wiederholung erhöhen
  if(taste<250)    {menueexit=1500;   }
  if ((TasteW>16)&(taste==10)){taste=110;return(taste);}
  if ((TasteW>16)&(taste==11)){taste=111;return(taste);}
  if ((TasteW>16)&(taste==12)){taste=112;return(taste);}
  if(taste==TasteA)  {taste=254;}
  if(taste<250)      {TasteA=taste;}
  if(taste==255)     {
    TasteA=253;
    TasteW=0;//Wiederholung rücksetzen
//    delay(1);
  } return(taste);
}
//**************************************************************************************************************
void HauptMenue(){
  bereich=1;
  lcd.clear();
  while(menueexit>0){
    delay(270);// Zeit für schleife
    taste=Tastatur();//Tastaturlesen 
    if (taste==10){      
      lcd.clear();
      //initalisieren();
      return;/*Hauptprogramm*/  
    }
    if ((taste==11) & (bereich>0)){
      bereich--;
    }
    if ((taste==12) & (bereich<1)){
      bereich++;
    }
    if ((taste==13)&(bereich==0)){
      MenueGeraet();
    }
    if ((taste==13)&(bereich>0)){
      MenueEinstellung();
    }

    lcd.setCursor( 0,0);
    if (bereich==0){
      lcd.print("Geraet              ");
    }
    if ((bereich>0)){
      lcd.print("Einstellungen");
      FormatI6(geraet);//formatiert rechtsbündig BYTEwert
      SensorMessen();
    }
  }//while
      //menueexit
   lcd.clear();
   return;/*Hauptprogramm*/  

}
void MenueGeraet(){
//  lcd.clear();
  index=geraet;
  me=0;//MenueEinteag
  //    WertLaden();
  while(menueexit>0){
    delay(60);// Zeit für schleife
    taste=Tastatur();//Tastaturlesen 
    if (taste==10){
      lcd.clear();
      return;
      //Hauptmenue();/*Hauptmenue*/
    }//taste10
    if ((taste==11) & (me==0) & (index>1)){
      index--;
      //WertLaden();
    }
    if ((taste==12) & (me==0) & (index<gegaetMax)){
      index++;
      //WertLaden();
    }
    if ((taste==13)&(me==0)){//Wertladen
      me=0;
      geraet=index;
      GeraetSichern();//Bereich 0 index als geraet
      VariablenLaden();
      taste=255;
      lcd.clear();
      menueexit=0;// verlasse gesamtes menü
      return;
    }
    //Submenue Anzeigen
    lcd.setCursor( 0,1);
      
        lcd.print("Geraet ?            ");
        lcd.setCursor( 12,1);
        FormatI6(index);//formatiert rechtsbündig BYTEwert
SensorMessen();    
    }//menueexit
      lcd.clear();
      return;
}//ende menue TARA

void MenueEinstellung(){
//  lcd.clear();
  index=0;
  me=0;//MenueAusgang
      WertLaden();
  while(menueexit>0){
    delay(60);// Zeit für schleife

    taste=Tastatur();//Tastaturlesen 
    if (taste==10){
      lcd.clear();
      return;
      //Hauptmenue();/*Hauptmenue*/
    }//taste10
    if ((taste==11) & (me==0) & (index>0)){
      index--;
      WertLaden();
    }
    if ((taste==12) & (me==0) & (index<4)){
      index++;
      WertLaden();
    }
    if ((taste==11) & (me==1) & (WertF>wertmin)){
      WertF--;
    }
    if ((taste==111) & (me==1) & (WertF>wertmin)){
      WertF-=5;
    }
    if ((taste==112) & (me==1) & (WertF<wertmax)){
      WertF+=5;
    }
    if ((taste==12) & (me==1) & (WertF<wertmax)){
      WertF++;
    }
    if ((taste==13)&(me==0)&(index==0)){//Tara
      WertF=kg;
      VarAllg[index]=WertF;
      WertSichern();
      taste=255;
    }
    if ((taste==13)&(me==0)&(index==1)){//Nullreferenz
      WertF=adWert;
      VarAllg[index]=WertF;
      WertSichern();
      taste=255;
    }
    if ((taste==13)&(me==0)&(index==2)){//Referenz Laden
      WertF=adWert;
      VarAllg[index]=WertF;
      WertSichern();
      taste=255;
    }
    if ((taste==13)&(me==0)&(index>2)){//Referenz Kg eingeben
      me=1;
      taste=255;
    }
    if ((taste==13)&(me==1)){//Wertsichern
      me=0;
      VarAllg[index]=WertF;
      WertSichern();
    }
    //Submenue Allgemein Anzeigen
    lcd.setCursor( 0,1);
    switch (index){
      case 0:
        lcd.print("Waage TARA     ");
        break;
      case 1:
        lcd.print("NULL Laden     ");
        break;
      case 2:
        lcd.print("Ref Laden      ");
        break;
      case 3:
        lcd.print("KG Ref         ");
        break; 
      case 4:
        lcd.print("KG Hoch        ");
        break; 
    }
    lcd.setCursor( 10,1);
    if (me==0){ lcd.print("=");}
      else{     lcd.print("?");}
    lcd.setCursor( 11,1);
    //lcd.print(Wert);
      FormatL8d0(WertF);//formatiert rechtsbündig BYTEwert
      SensorMessen();// 
    }//menueexit1
      lcd.clear();
      return;
}//ende menue Ausgang

//*************************************************************************************************************
void Grossezahl(byte zeile, byte pos, byte ziffer){
    switch( ziffer){
    case 0:
      lcd.setCursor(pos,zeile);
      lcd.print(char(2));
      lcd.print(char(5));
      lcd.print(char(1));
      lcd.print(char(32));
      lcd.setCursor(pos,zeile+1);
      lcd.print(char(2));
      lcd.print(char(6));
      lcd.print(char(1));
      lcd.print(char(32));
      break;
    case 1:
      lcd.setCursor(pos,zeile);
      lcd.print(char(32));
      lcd.print(char(8));
      lcd.print(char(1));
      lcd.print(char(32));
      lcd.setCursor(pos,zeile+1);
      lcd.print(char(32));
      lcd.print(char(32));
      lcd.print(char(1));
      lcd.print(char(32));
      break;
    case 2:
      lcd.setCursor(pos,zeile);
      lcd.print(char(8));//5
      lcd.print(char(3));
      lcd.print(char(1));
      lcd.print(char(32));
      lcd.setCursor(pos,zeile+1);
      lcd.print(char(2));
      lcd.print(char(4));
      lcd.print(char(6));
      lcd.print(char(32));
      break;
    case 3:
      lcd.setCursor(pos,zeile);
      lcd.print(char(5));
      lcd.print(char(3));
      lcd.print(char(1));
      lcd.print(char(32));
      lcd.setCursor(pos,zeile+1);
      lcd.print(char(6));
      lcd.print(char(4));
      lcd.print(char(1));
      lcd.print(char(32));
      break;
    case 4:
      lcd.setCursor(pos,zeile);
      lcd.print(char(2));
      lcd.print(char(6));
      lcd.print(char(1));
      lcd.print(char(32));
      lcd.setCursor(pos,zeile+1);
      lcd.print(char(32));
      lcd.print(char(32));
      lcd.print(char(1));
      lcd.print(char(32));
      break;
    case 5:
      lcd.setCursor(pos,zeile);
      lcd.print(char(2));
      lcd.print(char(3));
      lcd.print(char(5));
      lcd.print(char(32));
      lcd.setCursor(pos,zeile+1);
      lcd.print(char(6));
      lcd.print(char(4));
      lcd.print(char(1));
      lcd.print(char(32));
      break;
    case 6:
      lcd.setCursor(pos,zeile);
      lcd.print(char(2));
      lcd.print(char(3));
      lcd.print(char(5));
      lcd.print(char(32));
      lcd.setCursor(pos,zeile+1);
      lcd.print(char(2));
      lcd.print(char(4));
      lcd.print(char(1));
      lcd.print(char(32));
      break;
    case 7:
      lcd.setCursor(pos,zeile);
      lcd.print(char(5));
      lcd.print(char(5));
      lcd.print(char(1));
      lcd.print(char(32));
      lcd.setCursor(pos,zeile+1);
      lcd.print(char(32));
      lcd.print(char(2));//5
      lcd.print(char(32));//1
      lcd.print(char(32));
      break;
    case 8:
      lcd.setCursor(pos,zeile);
      lcd.print(char(2));
      lcd.print(char(3));
      lcd.print(char(1));
      lcd.print(char(32));
      lcd.setCursor(pos,zeile+1);
      lcd.print(char(2));
      lcd.print(char(4));
      lcd.print(char(1));
      lcd.print(char(32));
      break;
    case 9:
      lcd.setCursor(pos,zeile);
      lcd.print(char(2));
      lcd.print(char(3));
      lcd.print(char(1));
      lcd.print(char(32));
      lcd.setCursor(pos,zeile+1);
      lcd.print(char(32));
      lcd.print(char(7));
      lcd.print(char(1));
      lcd.print(char(32));
      break;
    case 10://-
      lcd.setCursor(pos,zeile);
      lcd.print(char(32));
      lcd.print(char(6));
      lcd.print(char(6));
      lcd.print(char(32));
      lcd.setCursor(pos,zeile+1);
      lcd.print(char(32));
      lcd.print(char(32));
      lcd.print(char(32));
      lcd.print(char(32));
      break;
    case 11://.
      lcd.setCursor(pos,zeile);
//      lcd.print(char(32));
      lcd.print(char(32));
      lcd.print(char(32));
//      lcd.print(char(32));
      lcd.setCursor(pos,zeile+1);
      //lcd.print(char(32));
      lcd.print(char(2));//161
      lcd.print(char(1));
      //lcd.print(char(32));
      break;
    case 12://H
      lcd.setCursor(pos,zeile);
      lcd.print(char(2));
      lcd.print(char(6));
      lcd.print(char(1));
      lcd.print(char(32));
      lcd.setCursor(pos,zeile+1);
      lcd.print(char(2));
      lcd.print(char(5));
      lcd.print(char(1));
      lcd.print(char(32));
      break;
    case 13://L
      lcd.setCursor(pos,zeile);
      lcd.print(char(2));
      lcd.print(char(32));
      lcd.print(char(32));
      lcd.print(char(32));
      lcd.setCursor(pos,zeile+1);
      lcd.print(char(2));
      lcd.print(char(6));
      lcd.print(char(6));
      lcd.print(char(32));
      break;
    default://=leer
      lcd.setCursor(pos,zeile);
      lcd.print(char(32));
      lcd.print(char(32));
      lcd.print(char(32));
      lcd.print(char(32));
      lcd.setCursor(pos,zeile+1);
      lcd.print(char(32));
      lcd.print(char(32));
      lcd.print(char(32));
      lcd.print(char(32));
      break;
    }  
}
void Wert4_1Gross(byte zeile,byte pos, long fanz){
  //-999.9 bis 9999.9 als anzeige in grossZeichen
  //darunter LL drueber HH
  long ganzezahl=fanz;// 
  int zahl=abs(ganzezahl/100);// wieder nur ganzzahl ohne faktor 10
  int dezi=abs((ganzezahl/10) %10);
  if (fanz<0){ 
    //negativ
  Grossezahl(zeile,pos,10);//-
    if(zahl<1000){
    
    //Hunderter
    if(zahl<100){
      Grossezahl(zeile,pos+4,99);//leer
    }else{
      Grossezahl(zeile,pos+4,((zahl/100)%10));
    }
    //Zehner
    if(zahl<10){
      Grossezahl(zeile,pos+8,99);//leer
    }else{
      Grossezahl(zeile,pos+8,((zahl/10)%10));
    }
    //Einer
    Grossezahl(zeile,pos+12,zahl%10);
    Grossezahl(zeile,pos+15,11);//.
    Grossezahl(zeile,pos+17,dezi);
  
  }
  else {//<999.9 
  Grossezahl(zeile,pos+4,13);//L
  Grossezahl(zeile,pos+8,13);//L
  Grossezahl(zeile,pos+12,13);//L
  Grossezahl(zeile,pos+15,11);//.
  Grossezahl(zeile,pos+17,13);//L
  }
  }else{
    //positiv
  if (zahl<10000){
    //Tausender
    if(zahl<1000){
      Grossezahl(zeile,pos,99);//leer
    }else{
      Grossezahl(zeile,pos,((zahl/1000)%10));
    }
    //Hunderter
    if(zahl<100){
      Grossezahl(zeile,pos+4,99);//leer
    }else{
      Grossezahl(zeile,pos+4,((zahl/100)%10));
    }
    //Zehner
    if(zahl<10){
      Grossezahl(zeile,pos+8,99);//leer
    }else{
      Grossezahl(zeile,pos+8,((zahl/10)%10));
    }
    //Einer
    Grossezahl(zeile,pos+12,zahl%10);
    Grossezahl(zeile,pos+15,11);//.
    Grossezahl(zeile,pos+17,dezi);
  
  }
  else {//>9999.9 
  Grossezahl(zeile,pos,99);//leer
  Grossezahl(zeile,pos+4,12);//H
  Grossezahl(zeile,pos+8,12);//H
  Grossezahl(zeile,pos+12,12);//H
  Grossezahl(zeile,pos+15,11);//.
  Grossezahl(zeile,pos+17,12);//H
  }
  }
}//grossen zahl
void Wert2_0Gross(byte zeile,byte pos,int wert){
  if (wert<0){ 
  Grossezahl(zeile,pos,99);
  Grossezahl(zeile,pos+3,99);
  }
  if (wert<100){
  
    if(wert<10){
      Grossezahl(zeile,pos,99);
    }else
  Grossezahl(zeile,pos,wert/10);
  Grossezahl(zeile,pos+3,wert%10);
  }
  else {//>99 
  Grossezahl(zeile,pos,12);
  Grossezahl(zeile,pos+3,12);
  
  }
}

//*******************************************************************************************************
void FormatI6(int zahl){
  int z=abs(zahl);
  if ((z<10000)&&(zahl>-1)){lcd.print(" ");}
  if (z<1000){lcd.print(" ");}
  if (z<100){lcd.print(" ");}
  if (z<10){lcd.print(" ");}
  if (zahl<0){lcd.print("-");};//Vorzeichen
  lcd.print(z);
}
void FormatL8d0(long zahl){
  //long g=zahl*10;
  long z=abs(zahl);
  //int a=abs(z);
  if (z<10){lcd.print(" ");}
  if (z<100){lcd.print(" ");}
  if (z<1000){lcd.print(" ");}
  if (z<10000){lcd.print(" ");}
  if (z<100000){lcd.print(" ");}
  if (z<100000){lcd.print(" ");}
  if ((z<100000)&(zahl>-1)){lcd.print(" ");}
  if (zahl<0){lcd.print("-");}
  lcd.print(z);

}

void FormatL6d1(long zahl){
  long g=zahl;
  long z=abs(g/100);
  int  d=abs((g %100) /10);
  //int a=abs(z);
  if (z<10){lcd.print(" ");}
  if (z<100){lcd.print(" ");}
  if (z<1000){lcd.print(" ");}
  if (z<10000){lcd.print(" ");}
  if ((z<10000)&(zahl>-1)){lcd.print(" ");}
  if (zahl<0){lcd.print("-");}
  lcd.print(z);
  lcd.print(".");
  lcd.print(d);
}
void FormatL6d2(long zahl){
  long g=zahl*10;
  long z=abs(g/10);
  int  d1=abs(g % 10);
  int  d2=abs(g % 100);
  //int a=abs(z);
  if (z<10){lcd.print(" ");}
  if (z<100){lcd.print(" ");}
  if (z<1000){lcd.print(" ");}
  if (z<10000){lcd.print(" ");}
  if ((z<10000)&(zahl>-1)){lcd.print(" ");}
  if (zahl<0){lcd.print("-");}
  lcd.print(z);
  lcd.print(".");
  lcd.print(d1);
  lcd.print(d2);
}
//**********************************************************************************************************
void GeraetLaden(){
      EEPROM.get(2, geraet);     // Lese Eintrag zu WertF 
      if (geraet<1){geraet=1;}
      if (geraet>gegaetMax){geraet=gegaetMax;}
}
void GeraetSichern(){
         EEPROM.put(2, geraet);// sichere struktur Settings
}

void VariablenLaden(){ 
  for (index=0;index<=VarAllgMax;index++){//0,1,2,3
    adress = (20*geraet)+(index*4);    //float hat 4 bytes
    EEPROM.get(adress, WertF);     // Lese Eintrag zu WertF 
    WertPruefen();
    EEPROM.put(adress, WertF);// sichere struktur Settings
    VarAllg[index]=WertF;
  }
}

void WertPruefen(){
          wertmin=WERTMINAllg[index];
          wertmax=WERTMAXAllg[index];
    if (WertF<wertmin) {WertF=wertmin;}
    if (WertF>wertmax) {WertF=wertmax;}
}

void WertLaden(){
  WertF=VarAllg[index];
  WertPruefen();
}

void WertSichern(){
    adress = (20*geraet)+(index*4);    //float und long hat 4 bytes
         EEPROM.put(adress, WertF);// sichere  Settings
}

﻿namespace AgOpenGPS
{
    public class CWaypoint
    {
        //pointers to mainform controls
        private readonly FormGPS mf;

        public CWaypoint(FormGPS _f)
        {
            //constructor
            mf = _f;
        }
    }
}
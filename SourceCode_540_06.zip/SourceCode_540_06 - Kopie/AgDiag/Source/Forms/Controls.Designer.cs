﻿namespace AgDiag
{
    public partial class FormLoop
    {
        public void TimedMessageBox(int timeout, string s1, string s2)
        {
            var form = new FormTimedMessage(timeout, s1, s2);
            form.Show();
        }
    }
}

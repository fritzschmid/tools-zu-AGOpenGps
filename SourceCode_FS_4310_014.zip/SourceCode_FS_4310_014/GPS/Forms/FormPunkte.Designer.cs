﻿namespace AgOpenGPS
{
    partial class FormPunkte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblPosNr1 = new System.Windows.Forms.Label();
            this.btnLoeschePositionsdateien1 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnCreateKml1 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.lblDateinamen = new System.Windows.Forms.Label();
            this.btnspeichereGPSNB1 = new System.Windows.Forms.Button();
            this.btnSpeichereGPSOB1 = new System.Windows.Forms.Button();
            this.btnSaveGPSposition1 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnPloeschen1 = new System.Windows.Forms.Button();
            this.lblPSNr1 = new System.Windows.Forms.Label();
            this.lblPSAltitude1 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.rbFutmNE1 = new System.Windows.Forms.RadioButton();
            this.listPunkt1 = new System.Windows.Forms.ListBox();
            this.rbLL1 = new System.Windows.Forms.RadioButton();
            this.label15 = new System.Windows.Forms.Label();
            this.rbUTMNE1 = new System.Windows.Forms.RadioButton();
            this.label14 = new System.Windows.Forms.Label();
            this.lblLatNorthDiff1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtLatNorth1 = new System.Windows.Forms.TextBox();
            this.txtLonEast1 = new System.Windows.Forms.TextBox();
            this.lblLongEastDiff1 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnAntenneB1 = new System.Windows.Forms.Button();
            this.btnAntenneA1 = new System.Windows.Forms.Button();
            this.txtABnamen1 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.btnABerstellen1 = new System.Windows.Forms.Button();
            this.lblBkoordinaten1 = new System.Windows.Forms.Label();
            this.lblAkoordinaten1 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.listAB1 = new System.Windows.Forms.ListBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lblDistanzFS2 = new System.Windows.Forms.Label();
            this.lblDistanz1 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblUTMnorth1 = new System.Windows.Forms.Label();
            this.lblUTMeast1 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblZone = new System.Windows.Forms.Label();
            this.lblLongitude = new System.Windows.Forms.Label();
            this.lblLatitude = new System.Windows.Forms.Label();
            this.lblEasting = new System.Windows.Forms.Label();
            this.lblNorthing = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblHDOP = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblAltitude = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblSatsTracked = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblFixQuality = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.nudX1 = new System.Windows.Forms.NumericUpDown();
            this.nudY1 = new System.Windows.Forms.NumericUpDown();
            this.cbPunktDieseZeile1 = new System.Windows.Forms.CheckBox();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudX1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudY1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(9, 153);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(473, 317);
            this.tabControl1.TabIndex = 229;
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(465, 284);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Datenstream";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lblPosNr1);
            this.tabPage2.Controls.Add(this.btnLoeschePositionsdateien1);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.btnCreateKml1);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.lblDateinamen);
            this.tabPage2.Controls.Add(this.btnspeichereGPSNB1);
            this.tabPage2.Controls.Add(this.btnSpeichereGPSOB1);
            this.tabPage2.Controls.Add(this.btnSaveGPSposition1);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(465, 284);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Position";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lblPosNr1
            // 
            this.lblPosNr1.AutoSize = true;
            this.lblPosNr1.Location = new System.Drawing.Point(163, 3);
            this.lblPosNr1.Name = "lblPosNr1";
            this.lblPosNr1.Size = new System.Drawing.Size(39, 20);
            this.lblPosNr1.TabIndex = 220;
            this.lblPosNr1.Text = "000";
            // 
            // btnLoeschePositionsdateien1
            // 
            this.btnLoeschePositionsdateien1.BackgroundImage = global::AgOpenGPS.Properties.Resources.BoundaryDelete;
            this.btnLoeschePositionsdateien1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnLoeschePositionsdateien1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoeschePositionsdateien1.Location = new System.Drawing.Point(354, 94);
            this.btnLoeschePositionsdateien1.Name = "btnLoeschePositionsdateien1";
            this.btnLoeschePositionsdateien1.Size = new System.Drawing.Size(110, 52);
            this.btnLoeschePositionsdateien1.TabIndex = 219;
            this.btnLoeschePositionsdateien1.Text = "Lösche Positionsdateien";
            this.btnLoeschePositionsdateien1.UseVisualStyleBackColor = true;
            this.btnLoeschePositionsdateien1.Click += new System.EventHandler(this.btnLoeschePositionsdateien1_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(179, 94);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 53);
            this.button1.TabIndex = 218;
            this.button1.Text = "Nur Punkte sammeln";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnCreateKml1
            // 
            this.btnCreateKml1.Location = new System.Drawing.Point(206, 27);
            this.btnCreateKml1.Name = "btnCreateKml1";
            this.btnCreateKml1.Size = new System.Drawing.Size(211, 61);
            this.btnCreateKml1.TabIndex = 215;
            this.btnCreateKml1.Text = "erstelle KML aus GPS Punkten";
            this.btnCreateKml1.UseVisualStyleBackColor = true;
            this.btnCreateKml1.Click += new System.EventHandler(this.btnCreateKml1_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label10.Location = new System.Drawing.Point(208, 150);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(185, 16);
            this.label10.TabIndex = 213;
            this.label10.Text = "Dateinamen für GPS Positionen";
            // 
            // lblDateinamen
            // 
            this.lblDateinamen.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateinamen.Location = new System.Drawing.Point(208, 166);
            this.lblDateinamen.Name = "lblDateinamen";
            this.lblDateinamen.Size = new System.Drawing.Size(209, 111);
            this.lblDateinamen.TabIndex = 214;
            this.lblDateinamen.Text = "GPS Sicherungs - Dateinamen";
            // 
            // btnspeichereGPSNB1
            // 
            this.btnspeichereGPSNB1.Location = new System.Drawing.Point(6, 185);
            this.btnspeichereGPSNB1.Name = "btnspeichereGPSNB1";
            this.btnspeichereGPSNB1.Size = new System.Drawing.Size(151, 83);
            this.btnspeichereGPSNB1.TabIndex = 216;
            this.btnspeichereGPSNB1.Text = "Speichere Position Option NurBrache";
            this.btnspeichereGPSNB1.UseVisualStyleBackColor = true;
            this.btnspeichereGPSNB1.Click += new System.EventHandler(this.btnspeichereGPSNB1_Click);
            // 
            // btnSpeichereGPSOB1
            // 
            this.btnSpeichereGPSOB1.Location = new System.Drawing.Point(6, 96);
            this.btnSpeichereGPSOB1.Name = "btnSpeichereGPSOB1";
            this.btnSpeichereGPSOB1.Size = new System.Drawing.Size(151, 83);
            this.btnSpeichereGPSOB1.TabIndex = 217;
            this.btnSpeichereGPSOB1.Text = "Speichere Position Option OhneBrache";
            this.btnSpeichereGPSOB1.UseVisualStyleBackColor = true;
            this.btnSpeichereGPSOB1.Click += new System.EventHandler(this.btnSpeichereGPSOB1_Click);
            // 
            // btnSaveGPSposition1
            // 
            this.btnSaveGPSposition1.Location = new System.Drawing.Point(5, 6);
            this.btnSaveGPSposition1.Name = "btnSaveGPSposition1";
            this.btnSaveGPSposition1.Size = new System.Drawing.Size(152, 84);
            this.btnSaveGPSposition1.TabIndex = 211;
            this.btnSaveGPSposition1.Text = "Speichere GPS-Position GanzesFeld";
            this.btnSaveGPSposition1.UseVisualStyleBackColor = true;
            this.btnSaveGPSposition1.Click += new System.EventHandler(this.btnSaveGPSposition1_Click_1);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.nudY1);
            this.tabPage3.Controls.Add(this.nudX1);
            this.tabPage3.Controls.Add(this.btnPloeschen1);
            this.tabPage3.Controls.Add(this.lblPSNr1);
            this.tabPage3.Controls.Add(this.lblPSAltitude1);
            this.tabPage3.Controls.Add(this.label26);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.rbFutmNE1);
            this.tabPage3.Controls.Add(this.listPunkt1);
            this.tabPage3.Controls.Add(this.rbLL1);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.rbUTMNE1);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.lblLatNorthDiff1);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.txtLatNorth1);
            this.tabPage3.Controls.Add(this.txtLonEast1);
            this.tabPage3.Controls.Add(this.lblLongEastDiff1);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(465, 284);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Punkt Suchen";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnPloeschen1
            // 
            this.btnPloeschen1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPloeschen1.Location = new System.Drawing.Point(107, 200);
            this.btnPloeschen1.Name = "btnPloeschen1";
            this.btnPloeschen1.Size = new System.Drawing.Size(65, 32);
            this.btnPloeschen1.TabIndex = 234;
            this.btnPloeschen1.Text = "P-löschen";
            this.btnPloeschen1.UseVisualStyleBackColor = true;
            this.btnPloeschen1.Click += new System.EventHandler(this.btnPloeschen1_Click);
            // 
            // lblPSNr1
            // 
            this.lblPSNr1.AutoSize = true;
            this.lblPSNr1.Location = new System.Drawing.Point(125, 4);
            this.lblPSNr1.Name = "lblPSNr1";
            this.lblPSNr1.Size = new System.Drawing.Size(39, 20);
            this.lblPSNr1.TabIndex = 235;
            this.lblPSNr1.Text = "000";
            // 
            // lblPSAltitude1
            // 
            this.lblPSAltitude1.AutoSize = true;
            this.lblPSAltitude1.Location = new System.Drawing.Point(83, 178);
            this.lblPSAltitude1.Name = "lblPSAltitude1";
            this.lblPSAltitude1.Size = new System.Drawing.Size(44, 20);
            this.lblPSAltitude1.TabIndex = 234;
            this.lblPSAltitude1.Text = "0.00";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(8, 178);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(70, 19);
            this.label26.TabIndex = 234;
            this.label26.Text = "Altitude:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.GreenYellow;
            this.label17.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(184, 7);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(242, 16);
            this.label17.TabIndex = 231;
            this.label17.Text = "Datenzeilen aus GpsPositionenFS.txt";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // rbFutmNE1
            // 
            this.rbFutmNE1.AutoSize = true;
            this.rbFutmNE1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbFutmNE1.Location = new System.Drawing.Point(18, 255);
            this.rbFutmNE1.Name = "rbFutmNE1";
            this.rbFutmNE1.Size = new System.Drawing.Size(130, 23);
            this.rbFutmNE1.TabIndex = 228;
            this.rbFutmNE1.TabStop = true;
            this.rbFutmNE1.Text = "Feld NorthEast";
            this.rbFutmNE1.UseVisualStyleBackColor = true;
            this.rbFutmNE1.CheckedChanged += new System.EventHandler(this.rbFutmNE1_CheckedChanged);
            // 
            // listPunkt1
            // 
            this.listPunkt1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listPunkt1.FormattingEnabled = true;
            this.listPunkt1.ItemHeight = 18;
            this.listPunkt1.Location = new System.Drawing.Point(178, 25);
            this.listPunkt1.Name = "listPunkt1";
            this.listPunkt1.Size = new System.Drawing.Size(281, 256);
            this.listPunkt1.TabIndex = 227;
            this.listPunkt1.SelectedIndexChanged += new System.EventHandler(this.listPunkt1_SelectedIndexChanged);
            // 
            // rbLL1
            // 
            this.rbLL1.AutoSize = true;
            this.rbLL1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbLL1.Location = new System.Drawing.Point(18, 200);
            this.rbLL1.Name = "rbLL1";
            this.rbLL1.Size = new System.Drawing.Size(91, 23);
            this.rbLL1.TabIndex = 220;
            this.rbLL1.TabStop = true;
            this.rbLL1.Text = "LatiLongi";
            this.rbLL1.UseVisualStyleBackColor = true;
            this.rbLL1.CheckedChanged += new System.EventHandler(this.rbLL1_CheckedChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(5, 4);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(103, 16);
            this.label15.TabIndex = 226;
            this.label15.Text = "Suchkoordinaten";
            // 
            // rbUTMNE1
            // 
            this.rbUTMNE1.AutoSize = true;
            this.rbUTMNE1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbUTMNE1.Location = new System.Drawing.Point(18, 229);
            this.rbUTMNE1.Name = "rbUTMNE1";
            this.rbUTMNE1.Size = new System.Drawing.Size(134, 23);
            this.rbUTMNE1.TabIndex = 221;
            this.rbUTMNE1.TabStop = true;
            this.rbUTMNE1.Text = "UTM NorthEast";
            this.rbUTMNE1.UseVisualStyleBackColor = true;
            this.rbUTMNE1.CheckedChanged += new System.EventHandler(this.rbUTMNE1_CheckedChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(8, 105);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(109, 19);
            this.label14.TabIndex = 225;
            this.label14.Text = "LatidudeNorth";
            // 
            // lblLatNorthDiff1
            // 
            this.lblLatNorthDiff1.AutoSize = true;
            this.lblLatNorthDiff1.ForeColor = System.Drawing.Color.Navy;
            this.lblLatNorthDiff1.Location = new System.Drawing.Point(4, 158);
            this.lblLatNorthDiff1.Name = "lblLatNorthDiff1";
            this.lblLatNorthDiff1.Size = new System.Drawing.Size(153, 20);
            this.lblLatNorthDiff1.TabIndex = 222;
            this.lblLatNorthDiff1.Text = "LatNorthDifferenz";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(8, 25);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(108, 19);
            this.label12.TabIndex = 224;
            this.label12.Text = "LongitudeEast";
            // 
            // txtLatNorth1
            // 
            this.txtLatNorth1.ForeColor = System.Drawing.Color.DarkGreen;
            this.txtLatNorth1.Location = new System.Drawing.Point(8, 129);
            this.txtLatNorth1.Name = "txtLatNorth1";
            this.txtLatNorth1.Size = new System.Drawing.Size(164, 26);
            this.txtLatNorth1.TabIndex = 218;
            this.txtLatNorth1.Text = "0";
            // 
            // txtLonEast1
            // 
            this.txtLonEast1.ForeColor = System.Drawing.Color.DarkGreen;
            this.txtLonEast1.Location = new System.Drawing.Point(8, 49);
            this.txtLonEast1.Name = "txtLonEast1";
            this.txtLonEast1.Size = new System.Drawing.Size(163, 26);
            this.txtLonEast1.TabIndex = 219;
            this.txtLonEast1.Text = "0";
            // 
            // lblLongEastDiff1
            // 
            this.lblLongEastDiff1.AutoSize = true;
            this.lblLongEastDiff1.ForeColor = System.Drawing.Color.Navy;
            this.lblLongEastDiff1.Location = new System.Drawing.Point(8, 78);
            this.lblLongEastDiff1.Name = "lblLongEastDiff1";
            this.lblLongEastDiff1.Size = new System.Drawing.Size(160, 20);
            this.lblLongEastDiff1.TabIndex = 223;
            this.lblLongEastDiff1.Text = "LongEastDifferenz";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.btnAntenneB1);
            this.tabPage4.Controls.Add(this.btnAntenneA1);
            this.tabPage4.Controls.Add(this.txtABnamen1);
            this.tabPage4.Controls.Add(this.label25);
            this.tabPage4.Controls.Add(this.btnABerstellen1);
            this.tabPage4.Controls.Add(this.lblBkoordinaten1);
            this.tabPage4.Controls.Add(this.lblAkoordinaten1);
            this.tabPage4.Controls.Add(this.label24);
            this.tabPage4.Controls.Add(this.label23);
            this.tabPage4.Controls.Add(this.listAB1);
            this.tabPage4.Controls.Add(this.label22);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(465, 284);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "AB aus Punkte";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // btnAntenneB1
            // 
            this.btnAntenneB1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAntenneB1.Location = new System.Drawing.Point(402, 116);
            this.btnAntenneB1.Name = "btnAntenneB1";
            this.btnAntenneB1.Size = new System.Drawing.Size(63, 46);
            this.btnAntenneB1.TabIndex = 10;
            this.btnAntenneB1.Text = "Antenne B";
            this.btnAntenneB1.UseVisualStyleBackColor = true;
            this.btnAntenneB1.Click += new System.EventHandler(this.btnAntenneB1_Click);
            // 
            // btnAntenneA1
            // 
            this.btnAntenneA1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAntenneA1.Location = new System.Drawing.Point(402, 32);
            this.btnAntenneA1.Name = "btnAntenneA1";
            this.btnAntenneA1.Size = new System.Drawing.Size(63, 46);
            this.btnAntenneA1.TabIndex = 9;
            this.btnAntenneA1.Text = "Antenne A";
            this.btnAntenneA1.UseVisualStyleBackColor = true;
            this.btnAntenneA1.Click += new System.EventHandler(this.btnAntenneA1_Click);
            // 
            // txtABnamen1
            // 
            this.txtABnamen1.Location = new System.Drawing.Point(290, 194);
            this.txtABnamen1.Name = "txtABnamen1";
            this.txtABnamen1.Size = new System.Drawing.Size(169, 26);
            this.txtABnamen1.TabIndex = 8;
            this.txtABnamen1.Text = "txtABnamen1";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ForeColor = System.Drawing.Color.DarkGreen;
            this.label25.Location = new System.Drawing.Point(287, 172);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(55, 20);
            this.label25.TabIndex = 7;
            this.label25.Text = "Name";
            // 
            // btnABerstellen1
            // 
            this.btnABerstellen1.Location = new System.Drawing.Point(290, 227);
            this.btnABerstellen1.Name = "btnABerstellen1";
            this.btnABerstellen1.Size = new System.Drawing.Size(169, 51);
            this.btnABerstellen1.TabIndex = 6;
            this.btnABerstellen1.Text = "A - B erstellen";
            this.btnABerstellen1.UseVisualStyleBackColor = true;
            this.btnABerstellen1.Click += new System.EventHandler(this.btnABerstellen1_Click);
            // 
            // lblBkoordinaten1
            // 
            this.lblBkoordinaten1.AutoSize = true;
            this.lblBkoordinaten1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBkoordinaten1.ForeColor = System.Drawing.Color.Blue;
            this.lblBkoordinaten1.Location = new System.Drawing.Point(287, 113);
            this.lblBkoordinaten1.Name = "lblBkoordinaten1";
            this.lblBkoordinaten1.Size = new System.Drawing.Size(115, 16);
            this.lblBkoordinaten1.TabIndex = 5;
            this.lblBkoordinaten1.Text = "lblBkoordinaten1";
            // 
            // lblAkoordinaten1
            // 
            this.lblAkoordinaten1.AutoSize = true;
            this.lblAkoordinaten1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAkoordinaten1.ForeColor = System.Drawing.Color.Blue;
            this.lblAkoordinaten1.Location = new System.Drawing.Point(288, 32);
            this.lblAkoordinaten1.Name = "lblAkoordinaten1";
            this.lblAkoordinaten1.Size = new System.Drawing.Size(103, 16);
            this.lblAkoordinaten1.TabIndex = 4;
            this.lblAkoordinaten1.Text = "lblAkoordinaten1";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.Color.DarkGreen;
            this.label24.Location = new System.Drawing.Point(286, 94);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(117, 20);
            this.label24.TabIndex = 3;
            this.label24.Text = "Punkt B (null)";
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.Color.DarkGreen;
            this.label23.Location = new System.Drawing.Point(286, 13);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(117, 20);
            this.label23.TabIndex = 2;
            this.label23.Text = "Punkt A (null)";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // listAB1
            // 
            this.listAB1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listAB1.FormattingEnabled = true;
            this.listAB1.ItemHeight = 18;
            this.listAB1.Location = new System.Drawing.Point(6, 22);
            this.listAB1.Name = "listAB1";
            this.listAB1.Size = new System.Drawing.Size(278, 256);
            this.listAB1.TabIndex = 1;
            this.listAB1.SelectedIndexChanged += new System.EventHandler(this.listAB1_SelectedIndexChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(6, 3);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(123, 16);
            this.label22.TabIndex = 0;
            this.label22.Text = "gespeicherte Punkte";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label21.Location = new System.Drawing.Point(295, 473);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(34, 13);
            this.label21.TabIndex = 236;
            this.label21.Text = "ZuAB";
            // 
            // lblDistanzFS2
            // 
            this.lblDistanzFS2.AutoSize = true;
            this.lblDistanzFS2.ForeColor = System.Drawing.Color.Blue;
            this.lblDistanzFS2.Location = new System.Drawing.Point(353, 473);
            this.lblDistanzFS2.Name = "lblDistanzFS2";
            this.lblDistanzFS2.Size = new System.Drawing.Size(41, 13);
            this.lblDistanzFS2.TabIndex = 233;
            this.lblDistanzFS2.Text = "label16";
            // 
            // lblDistanz1
            // 
            this.lblDistanz1.AutoSize = true;
            this.lblDistanz1.ForeColor = System.Drawing.Color.Blue;
            this.lblDistanz1.Location = new System.Drawing.Point(150, 473);
            this.lblDistanz1.Name = "lblDistanz1";
            this.lblDistanz1.Size = new System.Drawing.Size(41, 13);
            this.lblDistanz1.TabIndex = 234;
            this.lblDistanz1.Text = "label16";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.DarkGreen;
            this.label16.Location = new System.Drawing.Point(10, 473);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(143, 19);
            this.label16.TabIndex = 235;
            this.label16.Text = "Entfernung(null)";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 250;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblUTMnorth1
            // 
            this.lblUTMnorth1.AutoSize = true;
            this.lblUTMnorth1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUTMnorth1.Location = new System.Drawing.Point(300, 29);
            this.lblUTMnorth1.Name = "lblUTMnorth1";
            this.lblUTMnorth1.Size = new System.Drawing.Size(60, 20);
            this.lblUTMnorth1.TabIndex = 260;
            this.lblUTMnorth1.Text = "label22";
            // 
            // lblUTMeast1
            // 
            this.lblUTMeast1.AutoSize = true;
            this.lblUTMeast1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUTMeast1.Location = new System.Drawing.Point(300, 9);
            this.lblUTMeast1.Name = "lblUTMeast1";
            this.lblUTMeast1.Size = new System.Drawing.Size(60, 20);
            this.lblUTMeast1.TabIndex = 259;
            this.lblUTMeast1.Text = "label21";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label19.Location = new System.Drawing.Point(211, 6);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(89, 23);
            this.label19.TabIndex = 258;
            this.label19.Text = "UTM East";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label18.Location = new System.Drawing.Point(201, 26);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(101, 23);
            this.label18.TabIndex = 257;
            this.label18.Text = "UTM North";
            // 
            // lblZone
            // 
            this.lblZone.AutoSize = true;
            this.lblZone.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblZone.Location = new System.Drawing.Point(116, 131);
            this.lblZone.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblZone.Name = "lblZone";
            this.lblZone.Size = new System.Drawing.Size(49, 19);
            this.lblZone.TabIndex = 255;
            this.lblZone.Text = "Zone";
            this.lblZone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblLongitude
            // 
            this.lblLongitude.AutoSize = true;
            this.lblLongitude.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLongitude.Location = new System.Drawing.Point(302, 94);
            this.lblLongitude.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblLongitude.Name = "lblLongitude";
            this.lblLongitude.Size = new System.Drawing.Size(90, 19);
            this.lblLongitude.TabIndex = 249;
            this.lblLongitude.Text = "Longitude";
            // 
            // lblLatitude
            // 
            this.lblLatitude.AutoSize = true;
            this.lblLatitude.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLatitude.Location = new System.Drawing.Point(302, 114);
            this.lblLatitude.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblLatitude.Name = "lblLatitude";
            this.lblLatitude.Size = new System.Drawing.Size(77, 19);
            this.lblLatitude.TabIndex = 248;
            this.lblLatitude.Text = "Latitude";
            // 
            // lblEasting
            // 
            this.lblEasting.AutoSize = true;
            this.lblEasting.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEasting.Location = new System.Drawing.Point(300, 52);
            this.lblEasting.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblEasting.Name = "lblEasting";
            this.lblEasting.Size = new System.Drawing.Size(69, 19);
            this.lblEasting.TabIndex = 247;
            this.lblEasting.Text = "Easting";
            // 
            // lblNorthing
            // 
            this.lblNorthing.AutoSize = true;
            this.lblNorthing.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNorthing.Location = new System.Drawing.Point(300, 71);
            this.lblNorthing.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblNorthing.Name = "lblNorthing";
            this.lblNorthing.Size = new System.Drawing.Size(80, 19);
            this.lblNorthing.TabIndex = 246;
            this.lblNorthing.Text = "Northing";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label11.Location = new System.Drawing.Point(41, 127);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 23);
            this.label11.TabIndex = 256;
            this.label11.Text = "Zone";
            // 
            // lblHDOP
            // 
            this.lblHDOP.AutoSize = true;
            this.lblHDOP.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHDOP.Location = new System.Drawing.Point(110, 84);
            this.lblHDOP.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblHDOP.Name = "lblHDOP";
            this.lblHDOP.Size = new System.Drawing.Size(56, 19);
            this.lblHDOP.TabIndex = 253;
            this.lblHDOP.Text = "HDOP";
            this.lblHDOP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label8.Location = new System.Drawing.Point(28, 104);
            this.label8.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 23);
            this.label8.TabIndex = 252;
            this.label8.Text = "Altitude";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label7.Location = new System.Drawing.Point(205, 91);
            this.label7.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 23);
            this.label7.TabIndex = 251;
            this.label7.Text = "Longitiude";
            // 
            // lblAltitude
            // 
            this.lblAltitude.AutoSize = true;
            this.lblAltitude.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAltitude.Location = new System.Drawing.Point(110, 107);
            this.lblAltitude.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblAltitude.Name = "lblAltitude";
            this.lblAltitude.Size = new System.Drawing.Size(75, 19);
            this.lblAltitude.TabIndex = 250;
            this.lblAltitude.Text = "Altitude";
            this.lblAltitude.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Location = new System.Drawing.Point(5, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 23);
            this.label3.TabIndex = 245;
            this.label3.Text = "# Satellites";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(12, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 23);
            this.label2.TabIndex = 244;
            this.label2.Text = "Fix Quality";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(46, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 23);
            this.label1.TabIndex = 243;
            this.label1.Text = "Status";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Location = new System.Drawing.Point(229, 49);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 23);
            this.label5.TabIndex = 242;
            this.label5.Text = "Easting";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label6.Location = new System.Drawing.Point(225, 111);
            this.label6.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 23);
            this.label6.TabIndex = 241;
            this.label6.Text = "Latitude";
            // 
            // lblSatsTracked
            // 
            this.lblSatsTracked.AutoSize = true;
            this.lblSatsTracked.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSatsTracked.Location = new System.Drawing.Point(109, 61);
            this.lblSatsTracked.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblSatsTracked.Name = "lblSatsTracked";
            this.lblSatsTracked.Size = new System.Drawing.Size(44, 19);
            this.lblSatsTracked.TabIndex = 240;
            this.lblSatsTracked.Text = "Sats";
            this.lblSatsTracked.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Location = new System.Drawing.Point(217, 68);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 23);
            this.label4.TabIndex = 239;
            this.label4.Text = "Northing";
            // 
            // lblFixQuality
            // 
            this.lblFixQuality.AutoSize = true;
            this.lblFixQuality.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFixQuality.Location = new System.Drawing.Point(109, 35);
            this.lblFixQuality.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblFixQuality.Name = "lblFixQuality";
            this.lblFixQuality.Size = new System.Drawing.Size(70, 19);
            this.lblFixQuality.TabIndex = 238;
            this.lblFixQuality.Text = "FixQual";
            this.lblFixQuality.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.Location = new System.Drawing.Point(109, 9);
            this.lblStatus.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(61, 19);
            this.lblStatus.TabIndex = 237;
            this.lblStatus.Text = "Status";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.label9.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label9.Location = new System.Drawing.Point(34, 81);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 24);
            this.label9.TabIndex = 254;
            this.label9.Text = "HDOP";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // nudX1
            // 
            this.nudX1.Location = new System.Drawing.Point(123, 25);
            this.nudX1.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nudX1.Name = "nudX1";
            this.nudX1.Size = new System.Drawing.Size(48, 26);
            this.nudX1.TabIndex = 236;
            this.nudX1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudY1
            // 
            this.nudY1.Location = new System.Drawing.Point(123, 103);
            this.nudY1.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nudY1.Name = "nudY1";
            this.nudY1.Size = new System.Drawing.Size(48, 26);
            this.nudY1.TabIndex = 237;
            this.nudY1.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // cbPunktDieseZeile1
            // 
            this.cbPunktDieseZeile1.AutoSize = true;
            this.cbPunktDieseZeile1.Location = new System.Drawing.Point(273, 135);
            this.cbPunktDieseZeile1.Name = "cbPunktDieseZeile1";
            this.cbPunktDieseZeile1.Size = new System.Drawing.Size(166, 17);
            this.cbPunktDieseZeile1.TabIndex = 261;
            this.cbPunktDieseZeile1.Text = "Punkt in dieser Zeile einfügen";
            this.cbPunktDieseZeile1.UseVisualStyleBackColor = true;
            // 
            // FormPunkte
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(485, 495);
            this.Controls.Add(this.cbPunktDieseZeile1);
            this.Controls.Add(this.lblUTMnorth1);
            this.Controls.Add(this.lblUTMeast1);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.lblZone);
            this.Controls.Add(this.lblLongitude);
            this.Controls.Add(this.lblLatitude);
            this.Controls.Add(this.lblEasting);
            this.Controls.Add(this.lblNorthing);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.lblHDOP);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblAltitude);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblSatsTracked);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblFixQuality);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.lblDistanzFS2);
            this.Controls.Add(this.lblDistanz1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormPunkte";
            this.Text = "FormPunkte";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FormPunkte_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudX1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudY1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lblPosNr1;
        private System.Windows.Forms.Button btnLoeschePositionsdateien1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnCreateKml1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblDateinamen;
        private System.Windows.Forms.Button btnspeichereGPSNB1;
        private System.Windows.Forms.Button btnSpeichereGPSOB1;
        private System.Windows.Forms.Button btnSaveGPSposition1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnPloeschen1;
        private System.Windows.Forms.Label lblPSNr1;
        private System.Windows.Forms.Label lblPSAltitude1;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.RadioButton rbFutmNE1;
        private System.Windows.Forms.ListBox listPunkt1;
        private System.Windows.Forms.RadioButton rbLL1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RadioButton rbUTMNE1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblLatNorthDiff1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtLatNorth1;
        private System.Windows.Forms.TextBox txtLonEast1;
        private System.Windows.Forms.Label lblLongEastDiff1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btnAntenneB1;
        private System.Windows.Forms.Button btnAntenneA1;
        private System.Windows.Forms.TextBox txtABnamen1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button btnABerstellen1;
        private System.Windows.Forms.Label lblBkoordinaten1;
        private System.Windows.Forms.Label lblAkoordinaten1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ListBox listAB1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lblDistanzFS2;
        private System.Windows.Forms.Label lblDistanz1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblUTMnorth1;
        private System.Windows.Forms.Label lblUTMeast1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblZone;
        private System.Windows.Forms.Label lblLongitude;
        private System.Windows.Forms.Label lblLatitude;
        private System.Windows.Forms.Label lblEasting;
        private System.Windows.Forms.Label lblNorthing;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblHDOP;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblAltitude;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblSatsTracked;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblFixQuality;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown nudY1;
        private System.Windows.Forms.NumericUpDown nudX1;
        private System.Windows.Forms.CheckBox cbPunktDieseZeile1;
    }
}
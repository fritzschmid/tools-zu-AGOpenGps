﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgOpenGPS
{
    public partial class FormPunkte : Form
    {
        private readonly FormGPS mf = null;
        double aktuellEast = 0;
        double aktuellNorth = 0;
        double gesucht = 0;
        double ergebnis = 0;
        int SuchNr = -1;
        bool SuchDatei = false;
        int EinfuegeId = 0;

        private int A = 0, B = 0;
        //   private vec3[] arr;
        private CPunktFS Ap = new CPunktFS();
        private CPunktFS Bp = new CPunktFS();

        public FormPunkte(Form callingForm)
        {
            mf = callingForm as FormGPS;
            InitializeComponent();
        }

        private void FormPunkte_Load(object sender, EventArgs e)
        {
            string dirField;
            if (mf.currentFieldDirectory.Length > 3)
            {
                dirField = mf.fieldsDirectory + mf.currentFieldDirectory + "\\";
            }
            else
            {
                dirField = mf.fieldsDirectory + "\\"; //fieldsDirectory Root
            }
            lblDateinamen.Text = dirField + "GPSpositionen.txt";
            rbLL1.Checked = false;
            rbUTMNE1.Checked = false;
            lblLatNorthDiff1.Text = "0";
            lblLongEastDiff1.Text = "0";
            PunkteAuflisten();
            btnABerstellen1.Enabled = false;
        }
        private void ErstelleABaus2Punkte()
        {
            //calculate the AB Heading
            double abHead = Math.Atan2(Bp.FeldEast - Ap.FeldEast,
                Bp.FeldNorth - Ap.FeldNorth);
            if (abHead < 0) abHead += glm.twoPI;

            double offset = 0;// ((double)nudDistance.Value) / 200.0;

            double headingCalc = abHead + glm.PIBy2;

            mf.ABLine.lineArr.Add(new CABLines());
            mf.ABLine.numABLines = mf.ABLine.lineArr.Count;
            mf.ABLine.numABLineSelected = mf.ABLine.numABLines;

            int idx = mf.ABLine.numABLines - 1;

            mf.ABLine.lineArr[idx].heading = abHead;
            //calculate the new points for the reference line and points
            mf.ABLine.lineArr[idx].origin.easting = (Math.Sin(headingCalc) * Math.Abs(offset)) + Ap.FeldEast;
            mf.ABLine.lineArr[idx].origin.northing = (Math.Cos(headingCalc) * Math.Abs(offset)) + Ap.FeldNorth;

            if (!mf.bnd.bndArr[0].IsPointInsideBoundary(mf.ABLine.lineArr[idx].origin))
            {
                headingCalc = abHead - glm.PIBy2;
                mf.ABLine.lineArr[idx].origin.easting = (Math.Sin(headingCalc) * Math.Abs(offset)) + Ap.FeldEast;
                mf.ABLine.lineArr[idx].origin.northing = (Math.Cos(headingCalc) * Math.Abs(offset)) + Ap.FeldNorth;
            }

            //sin x cos z for endpoints, opposite for additional lines
            mf.ABLine.lineArr[idx].ref1.easting = mf.ABLine.lineArr[idx].origin.easting - (Math.Sin(mf.ABLine.lineArr[idx].heading) * 2000.0);
            mf.ABLine.lineArr[idx].ref1.northing = mf.ABLine.lineArr[idx].origin.northing - (Math.Cos(mf.ABLine.lineArr[idx].heading) * 2000.0);
            mf.ABLine.lineArr[idx].ref2.easting = mf.ABLine.lineArr[idx].origin.easting + (Math.Sin(mf.ABLine.lineArr[idx].heading) * 2000.0);
            mf.ABLine.lineArr[idx].ref2.northing = mf.ABLine.lineArr[idx].origin.northing + (Math.Cos(mf.ABLine.lineArr[idx].heading) * 2000.0);

            //create a name
            //mf.ABLine.lineArr[idx].Name = (Math.Round(glm.toDegrees(mf.ABLine.lineArr[idx].heading), 1)).ToString(CultureInfo.InvariantCulture)
            //      + "\u00B0" + mf.FindDirection(mf.ABLine.lineArr[idx].heading) + DateTime.Now.ToString("hh:mm:ss", CultureInfo.InvariantCulture);
            mf.ABLine.lineArr[idx].Name = txtABnamen1.Text;

        }

        private void PunkteAuflisten()
        {
            listPunkt1.Items.Clear();
            listAB1.Items.Clear();
            int i = 0;
            mf.FileLoadGPSpositionenFS();
            // ListViewItem itm;
            foreach (var item in mf.cPunktFs.punktArr)
            {
                //itm = new ListViewItem(item.Name);
                //listPunkt1.Items.Add(itm);
                if (rbLL1.Checked)
                {
                    listPunkt1.Items.Add(mf.cPunktFs.punktArr[i].Nr.ToString("000") + " " + mf.cPunktFs.punktArr[i].Longitude.ToString("###0.00000000") + " " + mf.cPunktFs.punktArr[i].Latidude.ToString("###0.00000000"));
                }
                if (rbUTMNE1.Checked)
                {
                    listPunkt1.Items.Add(mf.cPunktFs.punktArr[i].Nr.ToString("000") + " U " + mf.cPunktFs.punktArr[i].UTMEast.ToString("########0.00") + " " + mf.cPunktFs.punktArr[i].UTMNorth.ToString("#########0.00"));
                }
                if (rbFutmNE1.Checked)
                {
                    listPunkt1.Items.Add(mf.cPunktFs.punktArr[i].Nr.ToString("000") + " F  " + mf.cPunktFs.punktArr[i].FeldEast.ToString("######0.00") + "  " + mf.cPunktFs.punktArr[i].FeldNorth.ToString("######0.00"));
                }
                listAB1.Items.Add(mf.cPunktFs.punktArr[i].Nr.ToString("000") + " F  " + mf.cPunktFs.punktArr[i].FeldEast.ToString("######0.00") + "  " + mf.cPunktFs.punktArr[i].FeldNorth.ToString("######0.00"));

                i++;
            }
            lblAkoordinaten1.Text = "-";
            lblBkoordinaten1.Text = "-";
            A = 0;
            B = 0;

            if (SuchDatei)
            {
                listPunkt1.Items.Clear();
                i = 0;
                mf.FileLoadGPSpositionenSuche(0,(int)nudX1.Value,(int)nudY1.Value,(int)nudX1.Value,(int)nudY1.Value,0);
                // ListViewItem itm;
                foreach (var item in mf.cPunktFSuche.punktArr)
                {
                    //itm = new ListViewItem(item.Name);
                    //listPunkt1.Items.Add(itm);
                    if (rbLL1.Checked)
                    {
                        listPunkt1.Items.Add(mf.cPunktFSuche.punktArr[i].Nr.ToString("000") + " " + mf.cPunktFSuche.punktArr[i].Longitude.ToString("###0.00000000") + " " + mf.cPunktFSuche.punktArr[i].Latidude.ToString("###0.00000000"));
                    }
                    if (rbUTMNE1.Checked)
                    {
                        listPunkt1.Items.Add(mf.cPunktFSuche.punktArr[i].Nr.ToString("000") + " U " + mf.cPunktFSuche.punktArr[i].UTMEast.ToString("########0.00") + " " + mf.cPunktFSuche.punktArr[i].UTMNorth.ToString("#########0.00"));
                    }
 
                    i++;
                }

            }
            // go to bottom of list - if there is a bottom

        }
        private double DistanzFS(double x1, double y1, double x2, double y2)
        {
            return Math.Sqrt(Math.Pow((Math.Abs(x2) - Math.Abs(x1)), 2) + Math.Pow((Math.Abs(y2) - Math.Abs(y1)), 2));
            //return Math.Sqrt(Math.Pow(((x2) - (x1)), 2) + Math.Pow(((y2) - (y1)), 2));
        }
        private double EntfernungAB1()
        {
            /*
             *   original Formel              //how far are we away from the reference line at 90 degrees
                distanceFromRefLine = ((dy * pivot.easting) - (dx * pivot.northing) + (refABLineP2.easting
                                        * refABLineP1.northing) - (refABLineP2.northing * refABLineP1.easting))
                                            / Math.Sqrt((dy * dy) + (dx * dx));
*/
            double entfernungAB = 0;
            //x2-x1
            double dx = mf.ABLine.refABLineP2.easting - mf.ABLine.refABLineP1.easting;
            //z2-z1
            double dy = mf.ABLine.refABLineP2.northing - mf.ABLine.refABLineP1.northing;

            double dd = Math.Sqrt((dy * dy) + (dx * dx));//diagonale


            //how far are we away from the reference line at 90 degrees
            entfernungAB = ((dy * mf.pn.fix.easting) - (dx * mf.pn.fix.northing) +
                              (mf.ABLine.refABLineP2.easting * mf.ABLine.refABLineP1.northing) - (mf.ABLine.refABLineP2.northing * mf.ABLine.refABLineP1.easting))
                                        / dd;
            return entfernungAB;
        }

        public double String2Double(string eingabestring)
        {
            if (eingabestring.Length == 0) { return 0; }
            //eingabestring.Replace(",", ".");// komma berichtigen
            double ausgabe = 0;
            string c = "";
            int i = 0;
            double x = 0;
            bool negativ = false;
            int stelle = 0;
            int komma = 0;

            while (i < eingabestring.Length)
            {
                c = eingabestring.Substring(i, 1);
                if ("-".Contains(c))
                {
                    negativ = true;
                }

                if (".,".Contains(c))
                {
                    komma = 1;
                    stelle = -1;
                }
                if ("0123456789".Contains(c))
                {
                    if (komma == 0)
                    {
                        x = Convert.ToDouble(c);
                        //x = x * Math.Pow(10, stelle);
                        ausgabe = (ausgabe * 10) + x;
                        stelle++;
                    }
                    else
                    {
                        x = Convert.ToDouble(c);
                        x = x * (Math.Pow(10, stelle));
                        ausgabe = ausgabe + x;
                        stelle--;
                    }
                }
                i++;
            }
            if (negativ) ausgabe *= -1;
            return ausgabe;
        }






        private void timer1_Tick(object sender, EventArgs e)
        {
                 //all the fixings and position
                lblZone.Text = mf.Zone;
                if (mf.isJobStarted)
                {
                    lblEasting.Text = Math.Round(mf.pn.fix.easting, 2).ToString("0.00");
                    lblNorthing.Text = Math.Round(mf.pn.fix.northing, 2).ToString("0.00");
                }
                else
                {
                    lblEasting.Text = mf.pn.actualEasting.ToString("0.00");
                    lblNorthing.Text = mf.pn.actualNorthing.ToString("0.00");
                }
                lblUTMeast1.Text = mf.pn.actualEasting.ToString("0.00");
                lblUTMnorth1.Text = mf.pn.actualNorthing.ToString("0.00");

                lblLatitude.Text = mf.pn.latitude.ToString("0.00000000");
                lblLongitude.Text = mf.pn.longitude.ToString("0.00000000");
                //            lblLatitude.Text = mf.Latitude;
                //            lblLongitude.Text = mf.Longitude;
                lblAltitude.Text = mf.Altitude;
                int posnr = mf.PositionsNummer;
                lblPosNr1.Text = posnr.ToString("000");
                lblPSNr1.Text = posnr.ToString("000");

                if (rbLL1.Checked == true)
                {
                    aktuellNorth = mf.pn.latitude;
                    gesucht = String2Double(txtLatNorth1.Text);
                    ergebnis = aktuellNorth - gesucht;
                    lblLatNorthDiff1.Text = ergebnis.ToString("0.0000000");
                    aktuellEast = mf.pn.longitude;
                    gesucht = String2Double(txtLonEast1.Text);
                    ergebnis = aktuellEast - gesucht;
                    lblLongEastDiff1.Text = ergebnis.ToString("0.0000000");
                    lblDistanz1.Text = "-";
                    lblDistanzFS2.Text = "-";
                }
                if (rbUTMNE1.Checked == true)
                {
                    aktuellNorth = mf.pn.actualNorthing;
                    gesucht = String2Double(txtLatNorth1.Text);
                    ergebnis = aktuellNorth - gesucht;
                    lblLatNorthDiff1.Text = ergebnis.ToString("0.00");
                    aktuellEast = mf.pn.actualEasting;
                    gesucht = String2Double(txtLonEast1.Text);
                    ergebnis = aktuellEast - gesucht;
                    lblLongEastDiff1.Text = ergebnis.ToString("0.00");
                    lblDistanz1.Text = DistanzFS(String2Double(txtLonEast1.Text), String2Double(txtLatNorth1.Text), mf.pn.actualEasting, mf.pn.actualNorthing).ToString("0.00") + " m";
                    lblDistanzFS2.Text = "-";
                }
                if (rbFutmNE1.Checked == true)
                {
                    aktuellNorth = Math.Abs(mf.pn.fix.northing);
                    gesucht = Math.Abs(String2Double(txtLatNorth1.Text));
                    ergebnis = aktuellNorth - gesucht;
                    lblLatNorthDiff1.Text = ergebnis.ToString("0.00");
                    aktuellEast = Math.Abs(mf.pn.fix.easting);
                    gesucht = Math.Abs(String2Double(txtLonEast1.Text));
                    ergebnis = aktuellEast - gesucht;
                    lblLongEastDiff1.Text = ergebnis.ToString("0.00");
                    lblDistanz1.Text = DistanzFS(String2Double(txtLonEast1.Text), String2Double(txtLatNorth1.Text), mf.pn.fix.easting, mf.pn.fix.northing).ToString("0.00") + " m";
                    lblDistanzFS2.Text = (EntfernungAB1()).ToString("0.00" + " m");
                }

                //other sat and GPS info
                lblFixQuality.Text = mf.FixQuality;
                lblSatsTracked.Text = mf.SatsTracked;
                lblStatus.Text = mf.Status;
                lblHDOP.Text = mf.HDOP;
                /*
                tboxSerialFromRelay.Text = mf.mc.serialRecvRelayStr;
                tboxSerialToRelay.Text = mf.mc.relayData[0] + "," + mf.mc.relayData[1]
                     + "," + mf.mc.relayData[2] + "," + mf.mc.relayData[3] //relay and speed x 4
                     + "," + mf.mc.relayData[4] + "," + mf.mc.relayData[5] + "," + mf.mc.relayData[6]; //setpoint hi lo
                tboxNMEASerial.Text = mf.recvSentenceSettings;
                //tboxNMEASerial.Text = mainForm.pn.rawBuffer;

                tboxSerialFromAutoSteer.Text = mf.mc.serialRecvAutoSteerStr;
                tboxSerialToAutoSteer.Text = "32766, " + mf.mc.autoSteerData[mf.mc.sdRelayLo] + ", " + mf.mc.autoSteerData[mf.mc.sdSpeed]
                                        + ", " + mf.guidanceLineDistanceOff + ", " + mf.guidanceLineSteerAngle;
                */
          
        }

        private void btnSaveGPSposition1_Click_1(object sender, EventArgs e)
        {
            if (cbPunktDieseZeile1.Checked)
            {
                EinfuegeId = listPunkt1.SelectedIndex;
                mf.GpsPositionenInsert(EinfuegeId,1);
                PunkteAuflisten();
                listPunkt1.SelectedIndex = EinfuegeId + 1;
            }
            else
            {
                mf.FileCreateGPSpositionenFS(1); // auch unter AllePunkte speichern
                PunkteAuflisten();
            }

        }

        private void btnSpeichereGPSOB1_Click(object sender, EventArgs e)
        {
            if (cbPunktDieseZeile1.Checked)
            {
                EinfuegeId = listPunkt1.SelectedIndex;
                mf.GpsPositionenInsert(EinfuegeId,2);
                PunkteAuflisten();
                listPunkt1.SelectedIndex = EinfuegeId + 1;
            }
            else
            {
                mf.FileCreateGPSpositionenFS(2); // auch unter AllePunkte speichern
                PunkteAuflisten();
            }

        }

        private void btnspeichereGPSNB1_Click(object sender, EventArgs e)
        {
            if (cbPunktDieseZeile1.Checked)
            {
                EinfuegeId = listPunkt1.SelectedIndex;
                mf.GpsPositionenInsert(EinfuegeId, 4);
                PunkteAuflisten();
                listPunkt1.SelectedIndex = EinfuegeId + 1;
            }
            else
            {
                mf.FileCreateGPSpositionenFS(4); // auch unter AllePunkte speichern
                PunkteAuflisten();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //mf.FileCreateGPSpositionenNP();
            mf.FileCreateGPSpositionenFS(0); // auch unter AllePunkte speichern
            //PunktHinzufuegenFS(0);

        }

        private void btnLoeschePositionsdateien1_Click(object sender, EventArgs e)
        {
            mf.FileClearGPSpositionen();
        }

        private void btnCreateKml1_Click(object sender, EventArgs e)
        {
            mf.FileCreateAllGPSpositionenKML();
        }

        private void label16_Click(object sender, EventArgs e)
        {
            if (rbLL1.Checked)
            {
                txtLonEast1.Text = mf.pn.longitude.ToString("0.00000000");
                txtLatNorth1.Text = mf.pn.latitude.ToString("0.00000000");

            }
            if (rbUTMNE1.Checked)
            {
                txtLonEast1.Text = mf.pn.actualEasting.ToString("0.00");
                txtLatNorth1.Text = mf.pn.actualNorthing.ToString("0.00");
            }
            if (rbFutmNE1.Checked)
            {
                txtLonEast1.Text = mf.pn.fix.easting.ToString("0.00");
                txtLatNorth1.Text = mf.pn.fix.northing.ToString("0.00");
            }

        }

        private void rbLL1_CheckedChanged(object sender, EventArgs e)
        {
            PunkteAuflisten();
        }

        private void rbUTMNE1_CheckedChanged(object sender, EventArgs e)
        {
            PunkteAuflisten();
        }

        private void rbFutmNE1_CheckedChanged(object sender, EventArgs e)
        {
            PunkteAuflisten();
        }

        private void listPunkt1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i;
            i = listPunkt1.SelectedIndex;
            SuchNr = (int)mf.cPunktFs.punktArr[i].Nr;
            if (rbLL1.Checked)
            {
                txtLonEast1.Text = mf.cPunktFs.punktArr[i].Longitude.ToString();
                txtLatNorth1.Text = mf.cPunktFs.punktArr[i].Latidude.ToString();

            }
            if (rbUTMNE1.Checked)
            {
                txtLonEast1.Text = mf.cPunktFs.punktArr[i].UTMEast.ToString("0.00");
                txtLatNorth1.Text = mf.cPunktFs.punktArr[i].UTMNorth.ToString("0.00");

            }
            if (rbFutmNE1.Checked)
            {
                txtLonEast1.Text = mf.cPunktFs.punktArr[i].FeldEast.ToString("0.00");
                txtLatNorth1.Text = mf.cPunktFs.punktArr[i].FeldNorth.ToString("0.00");
            }
            lblPSAltitude1.Text = mf.cPunktFs.punktArr[i].Altitude.ToString("0.00");
            //mf.PositionsNummer = (int) mf.cPunktFs.punktArr[i].Nr;
        }

        private void listAB1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int verarbeiten = 1;
            int i = 0;
            string s = "";
            if (A == 0)
            {
                A = 1;
                //arr[A]
                i = listAB1.SelectedIndex;
                s = mf.cPunktFs.punktArr[i].Name + "\n" + "E=" + mf.cPunktFs.punktArr[i].FeldEast.ToString() + "\n" + "N=" + mf.cPunktFs.punktArr[i].FeldNorth.ToString();
                lblAkoordinaten1.Text = s;
                verarbeiten = 0;
                Ap.FeldEast = mf.cPunktFs.punktArr[i].FeldEast;
                Ap.FeldNorth = mf.cPunktFs.punktArr[i].FeldNorth;
            }
            if (B == 0 && verarbeiten == 1)
            {
                B = 1;
                //arr[A]
                i = listAB1.SelectedIndex;
                s = mf.cPunktFs.punktArr[i].Name + "\n" + "E=" + mf.cPunktFs.punktArr[i].FeldEast.ToString() + "\n" + "N=" + mf.cPunktFs.punktArr[i].FeldNorth.ToString();
                lblBkoordinaten1.Text = s;
                verarbeiten = 0;
                Bp.FeldEast = mf.cPunktFs.punktArr[i].FeldEast;
                Bp.FeldNorth = mf.cPunktFs.punktArr[i].FeldNorth;
            }
            //für entfernungsmessung
            rbFutmNE1.Checked = true;
            txtLonEast1.Text = mf.cPunktFs.punktArr[i].FeldEast.ToString();
            txtLatNorth1.Text = mf.cPunktFs.punktArr[i].FeldNorth.ToString();

            btnABerstellenCheck();
        }

        private void label23_Click(object sender, EventArgs e)
        {
            lblAkoordinaten1.Text = "-";
            A = 0;
            btnABerstellenCheck();

        }

        private void label24_Click(object sender, EventArgs e)
        {
            lblBkoordinaten1.Text = "-";
            B = 0;
            btnABerstellenCheck();

        }

        private void btnAntenneA1_Click(object sender, EventArgs e)
        {
            A = 1;
            lblAkoordinaten1.Text = "Antenne" + "\n" + "E=" + mf.pn.fix.easting.ToString("0.00") + "\n" + "N=" + mf.pn.fix.northing.ToString("0.00");
            Ap.FeldEast = mf.pn.fix.easting;
            Ap.FeldNorth = mf.pn.fix.northing;
            btnABerstellenCheck();
            //für entfernungsmessung
            rbFutmNE1.Checked = true;
            txtLonEast1.Text = mf.pn.fix.easting.ToString("0.00");
            txtLatNorth1.Text = mf.pn.fix.northing.ToString("0.00");

        }

        private void btnAntenneB1_Click(object sender, EventArgs e)
        {
            B = 1;
            lblBkoordinaten1.Text = "Antenne" + "\n" + "E=" + mf.pn.fix.easting.ToString("0.00") + "\n" + "N=" + mf.pn.fix.northing.ToString("0.00");
            Bp.FeldEast = mf.pn.fix.easting;
            Bp.FeldNorth = mf.pn.fix.northing;
            btnABerstellenCheck();

        }

        private void btnABerstellen1_Click(object sender, EventArgs e)
        {
            ErstelleABaus2Punkte();
            A = 0;
            B = 0;
            lblAkoordinaten1.Text = "-";
            lblBkoordinaten1.Text = "-";
            txtABnamen1.Text = "x";
            btnABerstellenCheck();
        }
        private void btnABerstellenCheck()
        {
            txtABnamen1.Text = DateTime.Now.ToString();
            if (A == 1 && B == 1)
            {
                btnABerstellen1.Enabled = true;
            }
            else
            {
                btnABerstellen1.Enabled = false;
            }

        }

        private void btnPloeschen1_Click(object sender, EventArgs e)
        {
            DialogResult result3 = MessageBox.Show("Punkt loeschen?",
        gStr.gsWaiting,
        MessageBoxButtons.YesNo,
        MessageBoxIcon.Question,
        MessageBoxDefaultButton.Button2);
            if (result3 == DialogResult.Yes)
            {

                int x = -1;
                int i = 0;
                foreach (var item in mf.cPunktFs.punktArr)
                {
                    if (SuchNr == mf.cPunktFs.punktArr[i].Nr) { x = i; }
                    i++;
                }
                if (x >= 0)
                {

                    mf.cPunktFs.punktArr.RemoveAt(x);
                    mf.FileSaveGPSpositionenFS(); // auch unter AllePunkte speichern
                    mf.FileLoadGPSpositionenFS();
                    PunkteAuflisten();
                }
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {
            
        }

        private void label17_Click(object sender, EventArgs e)
        {
            if (SuchDatei)
            {
                SuchDatei = false;
                label17.Text = "Datenzeilen aus GpsPositionenFS.txt";
                label17.BackColor = Color.GreenYellow;
                btnPloeschen1.Enabled = true;
            }
            else
            {
                SuchDatei = true;
                label17.Text = "Datenzeilen aus GpsPositionenSuche.txt";
                label17.BackColor = Color.Tomato;
                btnPloeschen1.Enabled = false;
            }
            PunkteAuflisten();
        }


    }
}
